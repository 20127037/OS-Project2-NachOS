// exception.cc
	//	Entry point into the Nachos kernel from user programs.
	//	There are two kinds of things that can cause control to
	//	transfer back to here from user code:
	//
	//	syscall -- The user code explicitly requests to call a procedure
	//	in the Nachos kernel. Right now, the only function we support is
	//	"Halt".
	//
	//	exceptions -- The user code does something that the CPU can't handle.
	//	For instance, accessing memory that doesn't exist, arithmetic errors,
	//	etc.
	//
	//	Interrupts (which can also cause control to transfer from user
	//	code into the Nachos kernel) are handled elsewhere.
	//
	// For now, this only handles the Halt() system call.
	// Everything else core dumps.
	//
	// Copyright (c) 1992-1993 The Regents of the University of California.
	// All rights reserved. See copyright.h for copyright notice and limitation
	// of liability and disclaimer of warranty provisions.
	
	#include "copyright.h"
	#include "system.h"
	#include "syscall.h"
	#include "math.h"
	#define MAX 200
	
	// increase program counter
	
	void IncreasePC()
	{
		int cur = machine->ReadRegister(PCReg);
		machine->WriteRegister(PrevPCReg, cur);
		//increase
		cur = machine->ReadRegister(NextPCReg);
		machine->WriteRegister(PCReg, cur);
	
		machine->WriteRegister(NextPCReg, cur + 4); //A MIPS instruction is 32 bits or 4 bytes (always).
	}


	void PrintInt()
	{
		bool isNega = false;
		
		int number = machine->ReadRegister(4);
		

		char* fal = new char[1];
		fal[0] = '0';
		

		if (number == 0)
		{
			gSynchConsole->Write(fal,1);		
			IncreasePC();
			return;
		}

		
		if(number < 0)
		{
			isNega = true;
			number *= (-1);
		}

		int len = (int)log10(number) + 1; // dem so chu so

		if (isNega) len += 1;
		char* buf = new char[len+1];
		buf[len] = '\0';

		int i = len - 1;
		while(number > 0)
		{
			buf[i] = (char)((number % 10) + '0');
			number /= 10;
			i--;
		}
		if(isNega) buf[0] = '-';
		gSynchConsole->Write(buf, len +1);
		return;
	}
	

	char* User2System(int virtAddr, int limit)
	{
		int i; //chi so index
		int oneChar;
		char* kernelBuf = NULL;
		kernelBuf = new char[limit + 1]; //can cho chuoi terminal
		if (kernelBuf == NULL)
			return kernelBuf;
		
		memset(kernelBuf, 0, limit + 1);
	
		for (i = 0; i < limit; i++)
		{
			machine->ReadMem(virtAddr + i, 1, &oneChar);
			kernelBuf[i] = (char)oneChar;
			if (oneChar == 0)
				break;
		}
		return kernelBuf;
	}


	int System2User(int virtAddr, int len, char* buffer)
	{
		if (len < 0) return -1;
		if (len == 0)return len;
		int i = 0;
		int oneChar = 0;
		do{
			oneChar = (int)buffer[i];
			machine->WriteMem(virtAddr + i, 1, oneChar);
			i++;
		} while (i < len && oneChar != 0);
		return i;
	}

	
	//----------------------------------------------------------------------
	// ExceptionHandler
	// Entry point into the Nachos kernel. Called when a user program
	//	is executing, and either does a syscall, or generates an addressing
	//	or arithmetic exception.
	//
	// For system calls, the following is the calling convention:
	//
	// system call code -- r2
	//	arg1 -- r4
	//	arg2 -- r5
	//	arg3 -- r6
	//	arg4 -- r7
	//
	//	The result of the system call, if any, must be put back into r2.
	//
	// And don't forget to increment the pc before returning. (Or else you'll
	// loop making the same system call forever!
	//
	//	"which" is the kind of exception. The list of possible exceptions
	//	are in machine.h.
	//----------------------------------------------------------------------
	
	void
	ExceptionHandler(ExceptionType which)
	{
		int type = machine->ReadRegister(2);
	
		switch(which)
		{
			case NoException:
				return;

			case PageFaultException:
				printf("PageFaultException dang dien ra");
				DEBUG('a', "No valid translation found\n");
				printf("No valid translation found\n");
				interrupt->Halt();
				break;
		
			case ReadOnlyException:
				DEBUG('a', "Write attempted to page marked read-only\n");
				printf("Write attempted to page marked read-only\n");
				interrupt->Halt();
				break;
		
			case BusErrorException:
				DEBUG('a', "Translation resulted invalid physical address\n");
				printf("Translation resulted invalid physical address\n");
				interrupt->Halt();
				break;
		
			case AddressErrorException:
				DEBUG('a', "Unaligned reference or one that was beyond the end of the address space\n");
				printf("Unaligned reference or one that was beyond the end of the address space\n");
				interrupt->Halt();
				break;
		
			case OverflowException:
				DEBUG('a', "Integer overflow in add or sub.\n");
				printf("Integer overflow in add or sub.\n");
				interrupt->Halt();
				break;
		
			case IllegalInstrException:
				DEBUG('a', "Unimplemented or reserved instr.\n");
				printf("Unimplemented or reserved instr.\n");
				interrupt->Halt();
				break;
		
			case NumExceptionTypes:
				DEBUG('a', "Number exception types\n");
				printf("Number exception types\n");
				interrupt->Halt();
				break;
		

			case SyscallException:
			{
				switch(type)
				{
					case SC_Halt:
						DEBUG('a', "Shutdown, initiated by user program.\n");
						interrupt->Halt();
						break;


					case SC_ReadInt:
						{
						    char* buffer;
						    int MAX_BUFFER = 255;
						    buffer = new char[MAX_BUFFER + 1];
						    int numbytes = gSynchConsole->Read(buffer, MAX_BUFFER);// doc buffer toi da MAX_BUFFER ki tu, tra ve so ki tu doc dc
						    int number = 0; // so luu ket qua tra ve cuoi cung
						
						    /* Qua trinh chuyen doi tu buffer sang so nguyen int */
			
						    // Xac dinh so am hay so duong                       
						    bool isNegative = false; // Gia thiet la so duong.
						    int firstNumIndex = 0;
						    int lastNumIndex = 0;
						    if(buffer[0] == '-')
						    {
							isNegative = true;
							firstNumIndex = 1;
							lastNumIndex = 1;                        			   		
						    }
						    
						    // Kiem tra tinh hop le cua so nguyen buffer
						    for(int i = firstNumIndex; i < numbytes; i++)					
						    {
							if(buffer[i] == '.') /// 125.0000000 van la so
							{
							    int j = i + 1;
							    for(; j < numbytes; j++)
							    {
								// So khong hop le
								if(buffer[j] != '0')
								{
								    printf("\n\n The integer number is not valid");
								    DEBUG('a', "\n The integer number is not valid");
								    machine->WriteRegister(2, 0);
								    IncreasePC();
								    delete buffer;
								    return;
								}
							    }
							    // la so thoa cap nhat lastNumIndex
							    lastNumIndex = i - 1;				
							    break;                           
							}
							else if(buffer[i] < '0' || buffer[i] > '9')
							{
							    printf("\n\n The integer number is not valid");
							    DEBUG('a', "\n The integer number is not valid");
							    machine->WriteRegister(2, 0);
							    IncreasePC();
							    delete buffer;
							    return;
							}
							lastNumIndex = i;    
						    }			
						    
						    // La so nguyen hop le, tien hanh chuyen chuoi ve so nguyen
						      
						    for(int i = firstNumIndex; i<= lastNumIndex; i++)
						    {
							if(number >= 214748364) 
							{
							    int remain = (int)(buffer[i] - 48);
							    if (number > 214748364 || ((isNegative == true && remain >= 8) || (isNegative == false && remain > 7)))
							    {
								    printf("\n\n The integer number is overflow");
								    DEBUG('a', "\n The integer number is overflow");
								    machine->WriteRegister(2, 0);
								    IncreasePC();
								    delete buffer;
								    return;
							    }
							}
							number = number * 10 + (int)(buffer[i] - 48); 
							
						    }
						    
						    

						    // neu la so am thi * -1;
						    if(isNegative)
						    {
							number = number * -1;
						    }
						    machine->WriteRegister(2, number);
						    IncreasePC();
						    delete buffer;
						    return;		
						}
						break;
	
					case SC_PrintInt:
						PrintInt();
						break;
	
					case SC_ReadChar:
					{
						int maxBytes = 255;
						char* buffer = new char[255];
						int numBytes = gSynchConsole->Read(buffer, maxBytes);

						if(numBytes >= 1) //Neu nhap nhieu hon 1 ky tu thi khong hop le
						{
							char c = buffer[0];
							machine->WriteRegister(2, c);
						}
						else  //Ky tu rong
						{
							printf("Ky tu rong!");
							DEBUG('a', "\nERROR: Ky tu rong!");
							machine->WriteRegister(2, 0);
						}
						

						delete buffer;
						
						break;
					}

					case SC_PrintChar:
					{
						char c = (char)machine->ReadRegister(4); // Doc ki tu tu thanh ghi r4
						gSynchConsole->Write(&c, 1); // In ky tu tu bien c, 1 byte
						
						break;

			}
	
					case SC_ReadString:
					{
						int virtAddr, length;
						char* buffer;
						virtAddr = machine->ReadRegister(4); // Lay dia chi tham so buffer truyen vao tu thanh ghi so 4
						length = machine->ReadRegister(5); // Lay do dai toi da cua chuoi nhap vao tu thanh ghi so 5
						buffer = User2System(virtAddr, length); // Copy chuoi tu vung nho User Space sang System Space
						gSynchConsole->Read(buffer, length); // Goi ham Read cua SynchConsole de doc chuoi
						System2User(virtAddr, length, buffer); // Copy chuoi tu vung nho System Space sang vung nho User Space
						delete buffer; 
						
						break;
					}

					case SC_PrintString:
					{
						int virtAddr;
						char* buffer;
						virtAddr = machine->ReadRegister(4); // Lay dia chi cua tham so buffer tu thanh ghi so 4
						buffer = User2System(virtAddr, 255); // Copy chuoi tu vung nho User Space sang System Space voi bo dem buffer dai 255 ki tu
						int length = 0;
						while (buffer[length] != 0) length++; // Dem do dai that cua chuoi
						gSynchConsole->Write(buffer, length + 1); // Goi ham Write cua SynchConsole de in chuoi
						delete buffer; 
						
						break;
					}
				}
				IncreasePC();
	
				break;
			}
			default:
				printf("Unexpected user mode exception %d %d\n", which, type);
				ASSERT(FALSE);
		}
	
	
}
