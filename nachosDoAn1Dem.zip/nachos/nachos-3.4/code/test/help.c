#include "syscall.h"

int main()
{	
	PrintString("------GIOI THIEU VE NHOM------\n\n");
	PrintString(" 20127040 Truong Gia Huy\n");
	PrintString(" 20127037 Le Nguyen Truong Huy\n");
	PrintString(" 20127560 Pham Tran Trung Luong\n");
	PrintString(" 20127594 Nguyen Thien Phu\n");
	PrintString(" 201270411 Do Dat Thanh\n\n");
	PrintString("------GIOI THIEU VE SC_ASCII------\n\n");
	PrintString("Chuong trinh se in ra day du bang ma ASCII\n\n");
	PrintString("------GIOI THIEU VE SC_SORT------\n\n");
	PrintString("Chuong trinh se sap xep 1 mang so nguyen thanh 1 day tang dan");
	PrintString("\n\n");
	

	Halt();
}
