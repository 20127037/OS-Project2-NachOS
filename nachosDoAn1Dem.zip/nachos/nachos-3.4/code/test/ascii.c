#include "syscall.h"
 
int main(){
    int i;
    char c = 0;
    for(i = 0; i < 256; ++i){
    	PrintString("Ki tu ascii thu ");
	PrintInt(i);
	PrintChar(':');
	PrintChar(c);
	c++;
	PrintString("\n");
    } 
    Halt();
}
