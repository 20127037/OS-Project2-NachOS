#include "syscall.h"

int main()
{	
	int n = 0;
	n = ReadInt();

	Halt();
	return 0;
}
